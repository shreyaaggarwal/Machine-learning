# -*- coding: utf-8 -*-
"""
Created on Fri Oct 13 14:35:16 2017

@author: Nitlaksh
"""

import numpy as np
import pandas as pd
emp = pd.read_csv("train.csv")
emp.columns
numerical_features = ["satisfaction_level","last_evaluation_rating",
           "projects_worked_on","average_montly_hours",
           "time_spend_company"]
categorical_features = ["Work_accident",
           "promotion_last_5years","Department","salary"]
#create dummy variable
def create_dummies(df, colname):
    col_dummies = pd.get_dummies(df[colname], prefix=colname)
    col_dummies.drop(col_dummies.columns[0], axis=1,inplace= True)
    df = pd.concat([df, col_dummies], axis=1)
    df.drop(colname, axis=1, inplace = True)
    return df

for c_feature in categorical_features:
    emp = create_dummies( emp, c_feature)
    
#splitting dataset
feature_columns = emp.columns.difference(['Attrition'])
feature_columns
from sklearn.cross_validation import train_test_split
train_X, test_X, train_y, test_y = train_test_split( emp[feature_columns],
                                                    emp['Attrition'],
                                                    test_size = 0.3,
                                                    random_state = 0)
#Regression Model
from sklearn.linear_model import LogisticRegression
logreg = LogisticRegression()
logreg.fit(train_X, train_y)
list(zip(feature_columns, logreg.coef_[0]))
logreg.intercept_
#predicting
y_pred = pd.DataFrame({'actual': test_y, 'predicted': logreg.predict( test_X)})
y_pred = y_pred.reset_index()
#comparing predictions with actual data
y_pred.sample( n = 10)
#acuracy
from sklearn import metrics

score = metrics.accuracy_score(y_pred.actual, y_pred.predicted)
round(float(score), 2 )

