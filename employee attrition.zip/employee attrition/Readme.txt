In the project I have predicted the probability of attrition for each ID using the Logistic Regression Approach.

For this I have used Spyder3(Python3.6) using sklearn

Packages used:
numpy
pandas
sklearn
sklearn.linear_model
LogisticRegression
sklearn.metrics


First of all I have read the csv file using Pandas.

Then, I have separated the numerical and categorical features

Then, dummy variables have been created manually for Logistic Regression.

The categorical features used as predictors and they need to be trasformed into dummy variables. 

Then, I have used sklearn.cross_validation.train_test_split module to identify training and testing data

The data has then been trained using:
logreg =LogistricRegression()
logreg.fit(train_X, train_y)

Then, prediction has been done using logreg.predict(test_X)

Then, accuracy has been measured using sklearn.metrics,accuracy_score

The accuracy of the model comes out to be 0.78

