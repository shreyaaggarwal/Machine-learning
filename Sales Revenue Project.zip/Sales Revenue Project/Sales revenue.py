# -*- coding: utf-8 -*-
"""
Predicting sales Revenue using Mahine Learning Approach
"""

import numpy as np
import pandas as pd
advt = pd.read_csv("Advertising.csv")
advt.head()
advt.info()
advt = advt[["TV", "radio", "newspaper", "sales"]]
advt.head()
import seaborn as sns
import matplotlib.pyplot as plt
sns.distplot( advt.sales )
sns.distplot( advt.newspaper)
sns.distplot( advt.radio )
sns.distplot( advt.TV )
#to use matplotlib magic function
from IPython import get_ipython
get_ipython().run_line_magic('matplotlib', 'inline')
#Sales vs Newspaper advertisement
sns.jointplot( advt.newspaper, advt.sales )
#sales vs tV advertisement
sns.jointplot( advt.TV, advt.sales )
#Visualizing pairwise correlation
sns.pairplot( advt )
#calculating correlations
advt.TV.corr( advt.sales )
advt.corr()
#visualizing correlation- the darker the color the stronger is the correlation
sns.heatmap( advt.corr() )
#building the model using sklearn

from sklearn.linear_model import LinearRegression
#splitting dataset in ratio training:testing = 70:30
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(
        advt[["TV", "radio", "newspaper"]],
        advt.sales,
        test_size=0.3,
        random_state = 42 )
len( X_train )
len( X_test )
#building model with linear regression
linreg = LinearRegression()
linreg.fit( X_train, y_train )
#finding the intercept b of equation y = mx+b and coefficients
linreg.intercept_
list( zip( ["TV", "radio", "newspaper"], list(linreg.coef_) ) )
#making predictions
y_pred = linreg.predict( X_test)
test_pred_df = pd.DataFrame( {'actual': y_test,
                            'predicted': np.round(y_pred,2),
                            'residuals': y_test - y_pred})
test_pred_df[0:10]#the o/p of this table varies with value of random_state
#Measuring Model Accuracy using metrics
#calculating RMS
from sklearn import metrics
rmse = np.sqrt(metrics.mean_squared_error( y_test, y_pred))
round(rmse, 2)
#evaluating model accuracy
#calculating R squared
metrics.r2_score(y_test, y_pred)
residuals = y_test - y_pred
sns.jointplot( advt.sales, residuals)
#K-Fold cross validation
from sklearn.cross_validation import cross_val_score
linreg = LinearRegression()
cross_val_score(linreg, X_train, y_train, scoring = 'r2', cv = 10 )
round( np.mean( cross_val_score( linreg,
                                X_train,
                                y_train, 
                                scoring = 'r2', 
                                cv = 10)), 2)

from sklearn.feature_selection import f_regression
F_values, p_values = f_regression(X_train, y_train)
F_values
['%3f' % p for p in p_values]
#exporting and importing the model
import pickle
linreg = LinearRegression()
linreg.fit(X_train, y_train)
from sklearn.externals import joblib 
joblib.dump(linreg, 'lin_model.pk1', compress=9)
model_clone = joblib.load('lin_model.pk1')
linreg.coef_


